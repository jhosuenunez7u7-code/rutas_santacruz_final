import matplotlib.pyplot as plt
import networkx as nx
import io
import base64

def generar_grafico(grafo, camino=None):
    G = nx.Graph()

    # Agregar aristas y pesos
    for ciudad, vecinos in grafo.lista.items():
        for vecino, peso in vecinos:
            G.add_edge(ciudad, vecino, weight=peso)

    # 📍 Posiciones reales aproximadas (basadas en mapa de Santa Cruz)
    posiciones = {
        "Yapacaní": (-7.8, 4),
        "Buena Vista": (-5.2, 3),
        "Portachuelo": (-2.1, 4.5),
        "Montero": (2.4, 4.4),
        "Warnes": (2.5, 2.1),
        "Santa Cruz": (1.5, -0.4),
        "Cotoca": (3.8, -0.2),
        "La Guardia": (1.5, -2.5),
        "El Torno": (-1.1, -3.8),
        "Samaipata": (-7.1, -4.6)
    }

    #  Obtener pesos (distancias)
    pesos = nx.get_edge_attributes(G, 'weight')

    #  Ajustes visuales generales
    plt.figure(figsize=(9, 8))
    nx.draw_networkx_nodes(
        G, posiciones,
        node_color="#e7a81f",   # Dorado
        node_size=1300,
        edgecolors='black'
    )
    nx.draw_networkx_labels(G, posiciones, font_size=9, font_weight='bold')
    nx.draw_networkx_edges(G, posiciones, width=2.2, edge_color='gray', alpha=0.6)

    # 📍 Etiquetas de distancia más grandes, centradas y con fondo blanco
    for (u, v, d) in G.edges(data=True):
        peso = d.get('weight', '')
        x = (posiciones[u][0] + posiciones[v][0]) / 2
        y = (posiciones[u][1] + posiciones[v][1]) / 2
        plt.text(
            x, y, f"{peso:.1f}",
            fontsize=11,
            color="black",
            ha="center", va="center",
            bbox=dict(
                boxstyle="round,pad=0.25",
                edgecolor="none",
                facecolor="white",
                alpha=0.9
            ),
            zorder=10  # 🔥 Esto sí asegura que el texto esté arriba de todo
        )

    #  Resalta el camino más corto (si existe)
    if camino:
        edges_camino = list(zip(camino, camino[1:]))
        nx.draw_networkx_edges(
            G, posiciones,
            edgelist=edges_camino,
            width=4,
            edge_color='#0066ff',
            alpha=0.9,
            style='solid'
        )

    #  Título y presentación
    plt.title("Mapa de Rutas - Santa Cruz", fontsize=13, fontweight='bold', pad=20)
    plt.axis("off")
    plt.tight_layout()

    # Exportar imagen a base64 (para mostrarla en Flask)
    buffer = io.BytesIO()
    plt.savefig(buffer, format='png', bbox_inches='tight')
    buffer.seek(0)
    imagen_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    plt.close()

    return imagen_base64
