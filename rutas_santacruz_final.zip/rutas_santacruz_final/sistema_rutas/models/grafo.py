from typing import Dict, List, Tuple
import heapq

class Grafo:
    def __init__(self, nombres_vertices: List[str]) -> None:
        self.nombres: List[str] = nombres_vertices[:]
        # Lista de adyacencia: ciudad -> [(vecino, peso), ...]
        self.lista: Dict[str, List[Tuple[str, float]]] = {v: [] for v in self.nombres}

    def agregar_arista(self, u: str, v: str, peso: float, bidireccional: bool = True) -> None:
        # Asegura que existan las llaves por si agregas ciudades nuevas
        if u not in self.lista:
            self.lista[u] = []
            if u not in self.nombres:
                self.nombres.append(u)
        if v not in self.lista:
            self.lista[v] = []
            if v not in self.nombres:
                self.nombres.append(v)

        # Inserta/actualiza arista
        self._reemplazar_o_append(self.lista[u], v, peso)
        if bidireccional:
            self._reemplazar_o_append(self.lista[v], u, peso)

    @staticmethod
    def _reemplazar_o_append(vecinos: List[Tuple[str, float]], destino: str, peso: float):
        for i, (w, _) in enumerate(vecinos):
            if w == destino:
                vecinos[i] = (destino, float(peso))
                return
        vecinos.append((destino, float(peso)))

    def camino_mas_corto(self, origen: str, destino: str) -> Tuple[List[str], float]:
        if origen not in self.lista or destino not in self.lista:
            return [], float("inf")

        dist: Dict[str, float] = {v: float("inf") for v in self.lista}
        prev: Dict[str, str] = {}
        dist[origen] = 0.0

        pq: List[Tuple[float, str]] = [(0.0, origen)]
        visitado: Dict[str, bool] = {}

        while pq:
            d, u = heapq.heappop(pq)
            if u in visitado:
                continue
            visitado[u] = True
            if u == destino:
                break

            for v, w in self.lista[u]:
                nd = d + w
                if nd < dist[v]:
                    dist[v] = nd
                    prev[v] = u
                    heapq.heappush(pq, (nd, v))

        if dist[destino] == float("inf"):
            return [], float("inf")

        # reconstruir camino
        camino = [destino]
        cur = destino
        while cur != origen:
            cur = prev[cur]
            camino.append(cur)
        camino.reverse()
        return camino, dist[destino]

#  Datos reales actualizados (Santa Cruz)
def grafo_santacruz() -> Grafo:
    ciudades = [
        "Santa Cruz", "Warnes", "Montero", "Portachuelo",
        "Buena Vista", "Yapacaní", "Cotoca", "La Guardia",
        "El Torno", "Samaipata"
    ]
    g = Grafo(ciudades)

    # 🛣️ Rutas principales (según Google Maps)
    g.agregar_arista("Yapacaní", "Buena Vista", 26.5)
    g.agregar_arista("Buena Vista", "Portachuelo", 31.4)
    g.agregar_arista("Portachuelo", "Montero", 18.4)
    g.agregar_arista("Montero", "Warnes", 24.9)
    g.agregar_arista("Warnes", "Santa Cruz", 33.5)
    g.agregar_arista("Santa Cruz", "Cotoca", 22.8)
    g.agregar_arista("Santa Cruz", "La Guardia", 18.2)
    g.agregar_arista("La Guardia", "El Torno", 13.2)
    g.agregar_arista("El Torno", "Samaipata", 86.7)
    
     

    return g

# ⚠️ ESTA LÍNEA ES LA QUE ARREGLA TU IMPORT
grafo = grafo_santacruz()
