from flask import Blueprint, render_template, request
from sistema_rutas.models.grafo import grafo as _grafo
from sistema_rutas.models.grafo_visual import generar_grafico

rutas_bp = Blueprint('rutas', __name__)

@rutas_bp.route('/')
def inicio():
    ciudades = _grafo.nombres
    return render_template('index.html', ciudades=ciudades)

@rutas_bp.route('/calcular', methods=['POST'])
def calcular():
    origen = request.form['origen']
    destino = request.form['destino']
    camino, distancia = _grafo.camino_mas_corto(origen, destino)

    # Generar imagen del grafo en base64
    grafo_img = generar_grafico(_grafo, camino)

    resultado = {
        "origen": origen,
        "destino": destino,
        "camino": camino,
        "distancia": distancia,
        "grafo_img": grafo_img
    }

    return render_template('index.html', ciudades=_grafo.nombres, resultado=resultado)
